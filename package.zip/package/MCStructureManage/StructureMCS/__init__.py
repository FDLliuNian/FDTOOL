"""
    mcstructure文件解析模块
    ---------------------------------
    * 可用对象 Mcstructure: 解析mcstructure文件的类
"""

from .mcstructure import Mcstructure